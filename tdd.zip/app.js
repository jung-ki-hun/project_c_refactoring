const express = require("express");
const axios = require("axios");
const app = express.express();
const cron = require("node-cron");

app.disable("x-powered-by"); // x-powered-by 헤더 비활성화
app.use(express.json());
app.use(express.urlencoded({ extends: true }));

app.get("/", (req, res) => {
  console.log("hi");
  // return res.status(302).redirect("/web/index.html");
});
app.all("*", (req, res, next) => {
  console.info(`req:${req.ip}  ${req.method} ${req.originalUrl}`);
  return next();
});
const sendData = function () {
  const params = {
    ma_name: "kihun",
    user_no: "2",
    state: 1,
    co_misae: Math.floor(Math.random() * (100 - 0)) + 0,
    co_humidity: Math.floor(Math.random() * (100 - 0)) + 0,
    co_temperature: Math.floor(Math.random() * (40 - 15)) + 15,
    co_no: 1,
  };
  axios.post("127.0.0.1:3000", params);
};
app.listen(3001, () => {
  console.log(`[${jkh_f.getDate.toLocaleString()}}] http://localhost:3000`);
  console.info();
});
//ip관련 처리 해줄것
